﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Andengine_Assistant_v1._0
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            
        }
        String filename_code; 
        OpenFileDialog ofd;
       // int new_im = 0;
        //int ratio_im = 0;
        Image img;
        private void button1_Click(object sender, EventArgs e)
        {
            groupBox_code.Enabled = true;      
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.Title = "Open Image";
                ofd.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.png; *.bmp)|*.jpg; *.jpeg; *.gif; *.png; *.bmp";
                if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    filename_code = ofd.SafeFileName;
                    //StreamReader ftext = new StreamReader(File.OpenRead(ofd.FileName));
                    img = Image.FromFile(ofd.FileName);
                    textBox2.Text = img.Width.ToString();
                    textBox3.Text = img.Height.ToString();

                   /* ratio_im = 0;
                    while(img.Width > 256 || img.Height > 256 )
                    {
                        img = resizeImage(img, new Size(img.Width/2, img.Height/2));
                        ratio_im++;
                    }
                    new_im++;
                    //imagelist.InitializeLifetimeService();
                    imagelist.ColorDepth = ColorDepth.Depth32Bit;
                   
                    imagelist.ImageSize = new Size(img.Width, img.Height);
                    
                    imagelist.Images.Add(new_im.ToString(), img);
                    
                    Image temp_im = imagelist.Images[new_im.ToString()];                   
                    
                    temp_im = resizeImage(temp_im, new Size(img.Width *(2*(ratio_im-1)), img.Height *(2*(ratio_im-1))));
                   
                    while (temp_im.Width > 360 || temp_im.Height > 640)
                    {
                        temp_im = resizeImage(temp_im, new Size(img.Width / 2, img.Height / 2));
                    }
                    pictureBox1.Image = temp_im;*/
                    pictureBox1.Image = img;


                }

        }
        public static Image resizeImage(Image imgToResize, Size size)
        {
            return (Image)(new Bitmap(imgToResize, size));//need enhance
        }
        int check_asset_kind = 1;
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            groupBox_tile_option.Enabled = false;
            check_asset_kind = 1;
            label_asset_type.Text = "Asset type : " + radioButton1.Text;
            groupBox_code.Text = "Code Options (" + radioButton1.Text + " Asset)"; 
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            groupBox_tile_option.Enabled = true;
            check_asset_kind = 2;
            label_asset_type.Text = "Asset type : " + radioButton2.Text;
            groupBox_code.Text = "Code Options (" + radioButton2.Text + " Asset)"; 
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            groupBox_tile_option.Enabled = true;
            check_asset_kind = 3;
            label_asset_type.Text = "Asset type : " + radioButton3.Text;
            groupBox_code.Text = "Code Options (" + radioButton3.Text + " Asset) "; 
        }
        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            groupBox_tile_option.Enabled = true;
            check_asset_kind = 4;
            label_asset_type.Text = "Asset type : " + radioButton4.Text;
            groupBox_code.Text = "Code Options (" + radioButton4.Text + " Asset)"; 
        }

        string WithoutExtension;
        string atlas_name;
        string region_name;
        string sprite_name;
        int pos_x;
        int pos_y;
        int size_x;
        int size_y;
        
        private void button3_Click(object sender, EventArgs e)
        {
            label_filename.Text = filename_code;
            WithoutExtension = Path.GetFileNameWithoutExtension(filename_code);
            atlas_name = WithoutExtension + "_atlas";
            region_name = WithoutExtension + "_region";
            sprite_name = WithoutExtension + "_sprite";
            label_atlas.Text = atlas_name;
            label_region.Text = region_name;
            label_sprite.Text = sprite_name;
            pos_x = Convert.ToInt32(textBox_x.Text);
            pos_y = Convert.ToInt32(textBox_y.Text);
            size_x = Convert.ToInt32(textBox2.Text);
            size_y = Convert.ToInt32(textBox3.Text);
            if (check_asset_kind == 1)
            {
                textBox_res_code.AppendText(Environment.NewLine);
                textBox_res_code.AppendText(Environment.NewLine);
                textBox_res_code.Text += "/////////////////////    " + WithoutExtension + " > " + label_asset_type.Text+ "    //////////////////";
                textBox_res_code.AppendText(Environment.NewLine); textBox_res_code.AppendText(Environment.NewLine);

                textBox_res_code.Text += "private BitmapTextureAtlas "+atlas_name+";     public ITextureRegion "+region_name+";";
                textBox_res_code.AppendText(Environment.NewLine); textBox_res_code.AppendText(Environment.NewLine);
                textBox_res_code.Text += atlas_name + " = new BitmapTextureAtlas(" + textBox_activity_res.Text + ".getTextureManager()," + size_x.ToString() + " , " + size_y.ToString() + ", TextureOptions.BILINEAR);";
                textBox_res_code.AppendText(Environment.NewLine);
                textBox_res_code.Text += region_name + " = BitmapTextureAtlasTextureRegionFactory.createFromAsset(" + atlas_name + "," + textBox_activity_res.Text + ".getAssets(), \"" + filename_code + "\", 0, 0);";
                textBox_res_code.AppendText(Environment.NewLine);
                textBox_res_code.Text += atlas_name + ".load();";
               
            }
            else if (check_asset_kind == 2 || check_asset_kind == 3 || check_asset_kind == 4)
            {
                textBox_res_code.AppendText(Environment.NewLine);
                textBox_res_code.AppendText(Environment.NewLine);
                textBox_res_code.Text += "/////////////////////    " + WithoutExtension + " > " + label_asset_type.Text + "    //////////////////";
                textBox_res_code.AppendText(Environment.NewLine);
                textBox_res_code.AppendText(Environment.NewLine);

                textBox_res_code.Text += "private BuildableBitmapTextureAtlas " + atlas_name + ";      public ITiledTextureRegion " + region_name + ";";
                textBox_res_code.AppendText(Environment.NewLine);
                textBox_res_code.Text += atlas_name + " = new BuildableBitmapTextureAtlas(" + textBox_activity_res.Text + ".getTextureManager()," + size_x.ToString() + " , " + size_y.ToString() + ", TextureOptions.BILINEAR);";
                textBox_res_code.AppendText(Environment.NewLine);
                textBox_res_code.Text += region_name + " = BitmapTextureAtlasTextureRegionFactory.createTiledFromAsset(" + atlas_name + "," + textBox_activity_res.Text + ".getAssets(), \"" + filename_code + "\", "+textBox_no_tiles.Text+", "+textBox_start_tile.Text+");";
                textBox_res_code.AppendText(Environment.NewLine);
                textBox_res_code.Text += "try {";
                textBox_res_code.AppendText(Environment.NewLine);
                textBox_res_code.Text += atlas_name + ".build(new BlackPawnTextureAtlasBuilder<IBitmapTextureAtlasSource, BitmapTextureAtlas>(0, 0, 0)); }";
                textBox_res_code.AppendText(Environment.NewLine);
                textBox_res_code.Text += "catch (ITextureAtlasBuilder.TextureAtlasBuilderException e) {";
                textBox_res_code.AppendText(Environment.NewLine);
                textBox_res_code.Text += "e.printStackTrace(); }";
                textBox_res_code.AppendText(Environment.NewLine);                
                textBox_res_code.Text += atlas_name + ".load();";
            }

            if (check_asset_kind == 1)
            {
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "/////////////////////    " + WithoutExtension + " > " + label_asset_type.Text + "    //////////////////";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "Sprite "+sprite_name+";" ;
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += sprite_name + " = new Sprite(" + pos_x.ToString() + "," + pos_y.ToString() + ", " + region_name + "," + textBox_scene_engine_name .Text+ ".getVertexBufferObjectManager());";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += textBox_scene_name.Text+".attachChild("+sprite_name+");";
                textBox_scene_code.AppendText(Environment.NewLine);

            }
            else if (check_asset_kind == 2)
            {
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "/////////////////////    " + WithoutExtension + " > " + label_asset_type.Text + "    //////////////////";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "ButtonSprite " + sprite_name + ";";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += sprite_name + " = new ButtonSprite(" + pos_x.ToString() + "," + pos_y.ToString() + ", " + region_name + "," + textBox_scene_engine_name.Text + ".getVertexBufferObjectManager()){";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "@Override";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "public boolean onAreaTouched(TouchEvent pSceneTouchEvent,float pTouchAreaLocalX, float pTouchAreaLocalY) {";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "if(pSceneTouchEvent.isActionDown()){";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "}";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "return super.onAreaTouched(pSceneTouchEvent, pTouchAreaLocalX, pTouchAreaLocalY);";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "}";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "};";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += textBox_scene_name.Text + ".attachChild(" + sprite_name + ");";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += textBox_scene_name.Text + ".registerTouchArea(" + sprite_name + ");";
                textBox_scene_code.AppendText(Environment.NewLine);

            }
            if (check_asset_kind == 3)
            {
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "/////////////////////    " + WithoutExtension + " > " + label_asset_type.Text + "    //////////////////";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "AnimatedSprite " + sprite_name + ";";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += sprite_name + " = new AnimatedSprite(" + pos_x.ToString() + "," + pos_y.ToString() + ", " + region_name + "," + textBox_scene_engine_name.Text + ".getVertexBufferObjectManager());";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += sprite_name + ".animate(100);";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += textBox_scene_name.Text + ".attachChild(" + sprite_name + ");";
                textBox_scene_code.AppendText(Environment.NewLine);

            }
            else if (check_asset_kind == 4)
            {
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "/////////////////////    " + WithoutExtension + " > " + label_asset_type.Text + "    //////////////////";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "TiledSprite " + sprite_name + ";";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += sprite_name + " = new TiledSprite(" + pos_x.ToString() + "," + pos_y.ToString() + ", " + region_name + "," + textBox_scene_engine_name.Text + ".getVertexBufferObjectManager()){";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "@Override";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "public boolean onAreaTouched(TouchEvent pSceneTouchEvent,float pTouchAreaLocalX, float pTouchAreaLocalY) {";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "if(pSceneTouchEvent.isActionDown()){";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "}";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "return super.onAreaTouched(pSceneTouchEvent, pTouchAreaLocalX, pTouchAreaLocalY);";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "}";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += "};";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += textBox_scene_name.Text + ".attachChild(" + sprite_name + ");";
                textBox_scene_code.AppendText(Environment.NewLine);
                textBox_scene_code.Text += textBox_scene_name.Text + ".registerTouchArea(" + sprite_name + ");";
                textBox_scene_code.AppendText(Environment.NewLine);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pos_x = Convert.ToInt32(textBox_x.Text);
            pos_y = Convert.ToInt32(textBox_y.Text);
            pictureBox1.Padding = new Padding(pos_x, pos_y, 0, 0);
            pictureBox1.Image = img;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            pos_y = Convert.ToInt32(textBox_y.Text);
            if (radioButton1.Checked)
            {
                pictureBox1.Padding = new Padding(Convert.ToInt32(textBox_scene_width.Text) / 2 - Convert.ToInt32(textBox2.Text) / 2, pos_y, 0, 0);
                pictureBox1.Image = img;
                textBox_x.Text = Convert.ToString(Convert.ToInt32(textBox_scene_width.Text) / 2 - Convert.ToInt32(textBox2.Text) / 2);
            }
            else
            {
                pictureBox1.Padding = new Padding(Convert.ToInt32(textBox_scene_width.Text) / 2 - Convert.ToInt32(textBox2.Text) / (Convert.ToInt32(textBox_no_tiles.Text)*2), pos_y, 0, 0);
                pictureBox1.Image = img;
                textBox_x.Text = Convert.ToString(Convert.ToInt32(textBox_scene_width.Text) / 2 - Convert.ToInt32(textBox2.Text) / (Convert.ToInt32(textBox_no_tiles.Text) * 2));
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox_res_code.Text = "";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox_scene_code.Text = "";
        }

        private void openNewAssetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button1_Click(sender,  e);
        }
        AboutBox about = new AboutBox();
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            about.Show();
        }




    }
}
